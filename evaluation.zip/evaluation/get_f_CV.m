function [objective,CV] = get_f_CV(pop, device_count)
%获取目标和约束违反程度
% Inputs:
%   pop - Population matrix
%   device_count - Number of IoT devices (passed to get_objective)
    
    objective = zeros(size(pop, 1), 2);
    CV = zeros(size(pop, 1),1);
    for i = 1: size(pop, 1)
        x = pop(i, :);
        [g2,g3,objective(i, 2),objective(i, 1)] = get_objective(x, device_count);
        % Total constraint violation (g2: computing capacity, g3: deadline)
        CV(i) = get_max(0, g2) + get_max(0, g3);
    end
end
function max_value = get_max(a, b)
    max_value = a;
    if b > a
        max_value = b;
    end
end