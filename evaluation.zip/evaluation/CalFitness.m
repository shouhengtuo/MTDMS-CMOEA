function Fitness = CalFitness(PopObj,CV)

%计算适应度值
    N = size(PopObj,1);
    % 两种输入方式
    if nargin < 2
        CV = zeros(size(PopObj,1),1);
    end
   % 决定支配关系矩阵
    Dominate = zeros(N); 
    for i = 1 : N-1
        for j = i+1 : N
            if CV(i) < CV(j)
                Dominate(i, j) = 1;
            elseif CV(i) > CV(j)
                Dominate(j, i) = 1;
            else
                if dominates(PopObj(i, :), PopObj(j, :))
                    Dominate(i, j) = 1;
                elseif dominates(PopObj(j, :), PopObj(i, :))
                    Dominate(j, i) = 1;
                end
            end
        end
    end
    
    % 对支配矩阵中的每行求和得到对应解支配解的数量
    S = sum(Dominate,2);
    
    % 计算fitness第一部分支配第i个解的相应解支配解的数量
    R = zeros(1,N);
    for i = 1 : N
        % 找到支配i的解
        index = logical(Dominate(:,i));
        R(i) = sum(S(index));
    end
    
    % 计算fitness第二部分
    % 计算任意两个解之间的距离
    Distance = pdist2(PopObj,PopObj);
    % 将对角线置为inf
    Distance(logical(eye(length(Distance)))) = inf;
    % 按行进行排列
    Distance = sort(Distance,2);
    D = 1./(Distance(:,floor(sqrt(N)))+2);
    % 计算fitness
    Fitness = R + D';
end
function result = dominates(solution1, solution2)
    % 检查solution1是否支配solution2
    if all(solution1 <= solution2) && any(solution1 < solution2)
        result = true;
    else
        result = false;
    end
end