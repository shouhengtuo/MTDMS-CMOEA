function [T_cons,computing_cons, E, T_sum,T] = get_objective(x, device_count)
%计算目标及约束值
% Inputs:
%   x - Decision variables
%   device_count - Number of IoT devices (replaces global count)
    
    % Use device_count parameter instead of global variable
    data_name = sprintf('%s%d.mat', 'data_', device_count);
    data = load(data_name);
    tasks = [];
    % 将计算任务提取出来
    for i =1:6
        tasks = [tasks, data.envir(i).Users];
    end
    % 设备的总数量
    user_count = device_count*6;
    T = zeros(1, user_count);
    E = zeros(1, user_count);
    T_local = 0;
    T_edge = 0;
    T_sum = 0;
    T_cons = zeros(1,user_count);
    computing_cons = zeros(1, 6);
    offload_status = x(1:user_count); % 卸载状态
    cache_status = x(user_count+1:user_count+120); % 缓存状态
    cache_status = reshape(cache_status,6,20);
%     security_status = x(user_count+121:end); % 安全状态
    % 统计每个边缘节点上所使用的计算量
    node_computing_count=zeros(1,6);
%     for i = 1:6
%         node_count(i) = sum(offload_status == i);
%     end
    E_cache = 0;
    for i =1:user_count
        % 本地执行不进行卸载
        if offload_status(i) == 0
            T(i) = tasks(i).comp_require * 10^6 / (tasks(i).comp_capacity * 10^9);
            E(i) = 10^-25 * (tasks(i).comp_capacity *10^9)^2 * tasks(i).comp_require * 10^6;
            T_local = T_local + T(i);
        else
        % 边缘服务器上计算
            edge_node_index = offload_status(i); % 目标卸载点序号
            edge_node = data.envir(edge_node_index); % 目标卸载点
            task = tasks(i); % 任务信息
            base_edge_node = data.envir(task.edge_node_index); % 任务所处的边缘节点
            [T_comm, E_comm] = communication_model(task,base_edge_node,edge_node,edge_node_index,cache_status);
            [T_comp, E_comp, computing_count] = computing_model(task,edge_node);
            node_computing_count(edge_node_index) = node_computing_count(edge_node_index)+ computing_count;
            if cache_status(edge_node_index, task.task_type) == 1
                E_cache = task.data_size * 1048576 * T_comp * 10^-9;
            end
            T(i) = T_comm + T_comp;
            E(i) = E_comm + E_comp + E_cache;
            T_edge = T_edge + T(i);
        end
        T_cons(i) = T(i) - tasks(i).deadline;
    end
    % Constraint 1: Computing capacity (with 10% tolerance for near-feasibility)
    computing_cons = node_computing_count - repmat(32*1.1,1,6);
    computing_cons(computing_cons < 0) = 0;
    computing_cons = sum(computing_cons);
    
    % Constraint 2: Deadline violations
    T_cons = real(T_cons);
    T_cons(T_cons < 0) = 0;
    T_cons = sum(T_cons);
%     problem = [];
% %     
%     for j = 1:300
%         if T_cons(j) > 0 
%             problem = [problem, j];
%         end
%     end
    T_cons = sum(T_cons);
    T_sum = real(get_max(sum(T_local),sum(T_edge)));
    E = real(sum(E));
end
function [T, E] = communication_model(task,base_edge_node,edge_node,edge_node_index,cache_status)
    base_edge_node_index = task.edge_node_index;
    task_type = task.task_type; % 任务类型
    g_k_n = 127 + 30 * log(sqrt((base_edge_node.x - task.x)^2 + (base_edge_node.y - task.y)^2));
    v_comm = 40 * 10^6 * log2(1 + 0.1 * g_k_n / 10^-13);
    % 在任务所在区域的边缘服务器执行
    if base_edge_node_index == edge_node_index
        if cache_status(edge_node_index,task_type) == 1
            % 如果该任务缓存在该边缘服务器，通信时延和能耗为0
            T = 0;
            E = 0;
        else
            T = task.data_size * 1048576 / v_comm;
            E = 0.1 * T;
        end
    % 不在任务所在区域的服务器执行，需要从该服务器转发至目标服务器
    else
        if cache_status(base_edge_node_index,task_type) == 1
        % 如果该任务缓存在该边缘服务器，通信时延和能耗为0
            T = 0;
            E = 0;
        else
            T = task.data_size * 1048576 / v_comm;
            E = 0.1 * T;
        end
        % 判断该类型任务是否缓存在目标服务器，如果缓存则不需要进行传播。
        if cache_status(edge_node_index,task_type) == 1
            T = T;
            E = E;
        else
            %task.data_size * 1048576
            T = T + (0.005 * sqrt((base_edge_node.x - edge_node.x)^2 + (base_edge_node.y - edge_node.y)^2) + 0.0223);
            E = E + task.data_size * 1048576 * sqrt((base_edge_node.x - edge_node.x)^2 + (base_edge_node.y - edge_node.y)^2) * 2 * 10^-8;
        end
    end
end
function[T, E, caclulate_capcity] = computing_model(task, edge_node) 
%     caclulate_capcity = 0.5 * rand(1,1) + 1;
    cycles = task.comp_require;
    if cycles >= 23
        caclulate_capcity = 1.25;
    else
        caclulate_capcity = 1;
    end
    T = cycles * 10^6 / (caclulate_capcity * 10^9);
    E = 10^-26 * (caclulate_capcity * 10^9)^2 * cycles * 10^6;
end
function[T, E] = security_model()
   T= 0;
   E= 0;
end
function max_value = get_max(a, b)
    if a >= b
        max_value = a;
    else
        max_value = b;
    end
end
