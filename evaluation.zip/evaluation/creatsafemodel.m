function L = creatsafemodel(best)
% CREATSAFEMODEL - Creates security-aware problem model based on best solution
% Determines dimension for Stage 3 security optimization
%
% Input:
%   best - Best solution from Stage 2 [1 x D+3]
%          Format: [decision_vars, latency, energy, CV]
%
% Output:
%   L    - Problem dimension for security optimization (number of offloaded tasks)
%
% Logic:
%   The function examines the offloading decisions (first count*6 variables)
%   to determine how many tasks are offloaded (non-zero entries)
%   This determines the dimension of the security optimization problem

% Extract problem dimension from best solution
D = length(best) - 3;  % Remove latency, energy, CV columns

% Calculate number of IoT devices from dimension
% D = count * 6 + 120, so count = (D - 120) / 6
count = (D - 120) / 6;

% Extract offloading decisions (first count variables indicate offloading)
% Each device has 6 decision variables, first variable is offloading decision
offloading_vars = best(1:6:count*6);  % Extract every 6th variable starting from 1

% Count number of offloaded tasks (non-zero offloading decisions)
% In the initialization, offloading decisions range from 0 to 6
% 0 means local processing, 1-6 means offload to different servers
L = sum(offloading_vars > 0);

% Ensure at least 1 dimension for security optimization
if L == 0
    L = 1;  % Minimum dimension
end

% Optional: Add validation
if L > count
    warning('Number of offloaded tasks (%d) exceeds device count (%d). Capping to count.', L, count);
    L = count;
end

end
