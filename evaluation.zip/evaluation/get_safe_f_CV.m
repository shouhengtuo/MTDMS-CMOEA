function [objective, CV] = get_safe_f_CV(pop)
% GET_SAFE_F_CV - Evaluates security-aware objectives and constraints
% Used in Stage 3 for security policy optimization
%
% Inputs:
%   pop - Population matrix [N x L] where L is number of offloaded tasks
%         Each column represents security level (1-5) for a task
%
% Outputs:
%   objective - Objective values [N x 2]
%               Column 1: Security cost (encryption overhead)
%               Column 2: Risk penalty (lower security = higher risk)
%   CV        - Constraint violation [N x 1]
%               Constraint: Balance between security levels
%
% Security Levels:
%   1 - Basic (low cost, high risk)
%   2 - Standard (moderate cost, moderate risk)
%   3 - Enhanced (balanced)
%   4 - High (high cost, low risk)
%   5 - Maximum (very high cost, minimal risk)

[N, L] = size(pop);

% Initialize outputs
objective = zeros(N, 2);
CV = zeros(N, 1);

% Security level parameters
% Cost factors (computational overhead for each security level)
cost_factors = [0.1, 0.3, 0.6, 1.0, 1.5];  % Normalized costs

% Risk factors (inverse security strength)
risk_factors = [1.0, 0.7, 0.5, 0.3, 0.1];  % Normalized risks

for i = 1:N
    % Extract security levels for current solution
    security_levels = pop(i, :);
    
    % Objective 1: Total security cost (encryption/decryption overhead)
    % Higher security levels incur more computational cost
    total_cost = 0;
    for j = 1:L
        level = round(security_levels(j));
        level = max(1, min(5, level));  % Ensure within bounds
        total_cost = total_cost + cost_factors(level);
    end
    objective(i, 1) = total_cost;
    
    % Objective 2: Total security risk
    % Lower security levels increase risk exposure
    total_risk = 0;
    for j = 1:L
        level = round(security_levels(j));
        level = max(1, min(5, level));
        total_risk = total_risk + risk_factors(level);
    end
    objective(i, 2) = total_risk;
    
    % Constraint: Security level variance should not be too high
    % This encourages balanced security policies
    if L > 1
        security_variance = var(security_levels);
        max_allowed_variance = 2.0;  % Maximum allowed variance
        
        if security_variance > max_allowed_variance
            CV(i) = security_variance - max_allowed_variance;
        else
            CV(i) = 0;
        end
    else
        CV(i) = 0;  % No constraint for single task
    end
end

% Optional: Add normalization for better optimization
% Normalize objectives to similar scales
objective(:, 1) = objective(:, 1) / L;  % Average cost per task
objective(:, 2) = objective(:, 2) / L;  % Average risk per task

end
