function [pop, fes_count] = PAR_stage3(L, iter_max)
% PAR_STAGE3 - Parallel version of third stage security-aware optimization
% Optimizes security policies for offloaded tasks based on Stage 2 decisions
%
% Inputs:
%   L       - Problem dimension (number of offloaded tasks)
%   iter_max - Maximum iterations for this stage
%
% Outputs:
%   pop     - Optimized population with security policies and objectives
%   fes_count - Number of function evaluations performed
%
% Note: Stage 3 is typically sequential as it operates on a single population

%% Initialization Phase
N = 100; % Population size
D = L;   % Problem dimension matches number of offloaded tasks

% Initialize FES counter
fes_count = 0;

% Define security level bounds (1=basic, 5=maximum encryption)
low = ones(1, D);    % Minimum security level per task
up = ones(1, D) * 5; % Maximum security level per task

% Initialize population with random security levels
pop = zeros(N, D);
for i = 1:D
    % Assign random security levels within bounds for each task
    pop(:, i) = randi([low(i), up(i)], [N, 1]);
end

% Evaluate initial population
[objective, CV] = get_safe_f_CV(pop); % Get security-aware objectives/constraints
fes_count = fes_count + N;  % Count initial evaluation

% Calculate initial fitness
fitness = CalFitness(objective, CV);

%% Evolutionary Loop
iter = 0;
while iter < iter_max
    %% 1. Parent Selection via Tournament
    % Select three parent populations for DE operations
    Mat1 = TournamentSelection(2, N, fitness); % Parent 1 indices
    Mat2 = TournamentSelection(2, N, fitness); % Parent 2 indices  
    Mat3 = TournamentSelection(2, N, fitness); % Parent 3 indices
    
    %% 2. Differential Evolution Operation
    % Generate offspring using specialized security-aware DE operator
    offspring = OperatorSafeDE(pop, pop(Mat1,:), pop(Mat2,:), pop(Mat3,:));
    
    %% 3. Offspring Evaluation
    [objective_off, CV_off] = get_safe_f_CV(offspring);
    fes_count = fes_count + N;  % Count offspring evaluation
    
    %% 4. Environmental Selection
    % Combine parent and offspring populations
    Q = [pop; offspring];
    Q_objective = [objective; objective_off];
    Q_CV = [CV; CV_off];
    
    % Select next generation using constrained non-dominated sorting
    [Next, fitness] = EnvironmentalSelection(Q, Q_CV, N, true);
    
    %% 5. Population Update
    pop = Q(Next, :);          % Selected individuals
    objective = Q_objective(Next, :); % Their objectives
    CV = Q_CV(Next, :);        % Their constraint violations
    fitness = fitness(Next);   % Their fitness values
    
    iter = iter + 1; % Increment iteration counter
end

%% Final Output Preparation
% Append objectives and constraint violations to decision variables
pop = [pop, objective, CV];
end
