function pop = PAR_evolve1(pop1, pop2, pop3, pop4, iter_max, device_count)
% PAR_EVOLVE1 - Parallel version of evolve1 for constrained multi-objective optimization
% Eliminates global variable dependency for parallel execution
%
% Inputs:
%   pop1-pop4 - Four subpopulations from membrane division
%   iter_max  - Maximum iterations
%   device_count - Number of IoT devices (passed to get_f_CV)
%
% Output:
%   pop       - Merged optimized population

N = size(pop1, 1);
D = size(pop1, 2);
pop = zeros(N, D);

iter1 = 0;
while iter1 < iter_max
    % Calculate fitness for each population
    fitness1 = CalFitness(pop1(:,(D-2):(D-1)), pop1(:,D));
    fitness2 = CalFitness(pop2(:,(D-2):(D-1)), pop2(:,D));
    fitness3 = CalFitness(pop3(:,(D-2):(D-1)), pop3(:,D));
    fitness4 = CalFitness(pop4(:,(D-2):(D-1)), pop4(:,D));
    
    % Parent selection using tournament
    Mat1 = TournamentSelection(2, N, fitness1);
    
    % DE/best/1 for population 2
    Mat2_1 = TournamentSelection(2, N, fitness2);
    Mat2_2 = TournamentSelection(2, N, fitness2);
    
    % DE/rand/1 for population 3
    Mat3_1 = TournamentSelection(2, N, fitness3);
    Mat3_2 = TournamentSelection(2, N, fitness3);
    Mat3_3 = TournamentSelection(2, N, fitness3);
    
    % DE/current-to-rand/1 for population 4
    Mat4_1 = TournamentSelection(2, N, fitness4);
    Mat4_2 = TournamentSelection(2, N, fitness4);
    Mat4_3 = TournamentSelection(2, N, fitness4);
    
    % Generate offspring using different DE strategies (no global variable dependency)
    % DE/best/1: use elite from pop1 as base
    offspring2 = PAR_OperatorDE_best(pop1(Mat1,1:(D-3)), pop2(Mat2_1,1:(D-3)), pop2(Mat2_2,1:(D-3)));
    % DE/rand/1: random base selection
    offspring3 = OperatorDE_rand_1(pop3(Mat3_1,1:(D-3)), pop3(Mat3_2,1:(D-3)), pop3(Mat3_3,1:(D-3)));
    % DE/current-to-rand/1: current-to-random mutation
    offspring4 = PAR_OperatorDE_current(pop4(:,1:(D-3)), pop4(Mat4_1,1:(D-3)), pop4(Mat4_2,1:(D-3)), pop4(Mat4_3,1:(D-3)));
    
    % Evaluate offspring
    [objective_2, CV_2] = get_f_CV(offspring2, device_count);
    [objective_3, CV_3] = get_f_CV(offspring3, device_count);
    [objective_4, CV_4] = get_f_CV(offspring4, device_count);
    
    % Combine parents and offspring
    Q_2 = [pop2(:,1:(D-3)); offspring2];
    Q_3 = [pop3(:,1:(D-3)); offspring3];
    Q_4 = [pop4(:,1:(D-3)); offspring4];
    Q_Obj_2 = [pop2(:,(D-2):(D-1)); objective_2];
    Q_Obj_3 = [pop3(:,(D-2):(D-1)); objective_3];
    Q_Obj_4 = [pop4(:,(D-2):(D-1)); objective_4];
    Q_CV_2 = [pop2(:,D); CV_2];
    Q_CV_3 = [pop3(:,D); CV_3];
    Q_CV_4 = [pop4(:,D); CV_4];
    
    % Constraint-dominated environmental selection
    [Next_2, fitness2] = EnvironmentalSelection(Q_Obj_2, Q_CV_2, N, true);
    [Next_3, fitness3] = EnvironmentalSelection(Q_Obj_3, Q_CV_3, N, true);
    [Next_4, fitness4] = EnvironmentalSelection(Q_Obj_4, Q_CV_4, N, true);
    
    offspring2 = Q_2(Next_2, :);
    offspring3 = Q_3(Next_3, :);
    offspring4 = Q_4(Next_4, :);
    
    pop2 = [offspring2, Q_Obj_2(Next_2,:), Q_CV_2(Next_2,:)];
    pop3 = [offspring3, Q_Obj_3(Next_3,:), Q_CV_3(Next_3,:)];
    pop4 = [offspring4, Q_Obj_4(Next_4,:), Q_CV_4(Next_4,:)];
    
    % Merge all populations
    pop = [pop1; pop2; pop3; pop4];
    fitness = [fitness1(:); fitness2(Next_2)'; fitness3(Next_3)'; fitness4(Next_4)'];
    
    % Redistribute population based on fitness
    [pop1, ~, ~, ~] = dividepop(pop, fitness);
    pop = [pop1; pop2; pop3; pop4];
    
    iter1 = iter1 + 1;
end
end
