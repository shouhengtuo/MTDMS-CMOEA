function [pop, fes_count] = PAR_stage1(pop, iter_max, type, device_count)
% PAR_STAGE1 - Parallel version of first stage in MTDMS-CMOEA algorithm
% Performs specialized evolution based on problem type in membrane structure
%
% Inputs:
%   pop      - Initial population matrix [N x D]
%   iter_max - Maximum iterations for this stage
%   type     - Membrane type (1-4) determining optimization strategy
%   device_count - Number of IoT devices (passed to get_f_CV)
%
% Outputs:
%   pop      - Optimized population with appended objectives and constraints
%   fes_count - Number of function evaluations performed
%
% Note: This function is designed to be called within parfor loops

% Get population size and problem dimension
[NP, D] = size(pop);

% Initialize FES counter
fes_count = 0;

% Type 1: Constrained multi-objective optimization
if type == 1
    % Evaluate objectives and constraint violations
    [objective, CV] = get_f_CV(pop, device_count);
    fes_count = fes_count + NP;  % Count initial evaluation
    
    % Calculate fitness considering both objectives and constraints
    fitness = CalFitness(objective, CV);
    
    % Append objectives and CV to population matrix
    pop = [pop, objective, CV];
    
    % Divide population into 4 subpopulations based on fitness
    [pop1, pop2, pop3, pop4] = dividepop(pop, fitness);
    
    % Evolve subpopulations with type-specific strategy
    pop = PAR_evolve1(pop1, pop2, pop3, pop4, iter_max, device_count);
    fes_count = fes_count + iter_max * NP;  % Count evolution evaluations

% Type 2: Unconstrained multi-objective optimization    
elseif type == 2
    [objective, CV] = get_f_CV(pop, device_count);
    fes_count = fes_count + NP;  % Count initial evaluation
    
    fitness = CalFitness(objective); % Fitness without CV
    
    pop = [pop, objective, CV];
    [pop1, pop2, pop3, pop4] = dividepop(pop, fitness);
    pop = PAR_evolve2(pop1, pop2, pop3, pop4, iter_max, device_count);
    fes_count = fes_count + iter_max * NP;  % Count evolution evaluations

% Type 3: Constrained latency optimization (single-objective)
elseif type == 3
    [objective, CV] = get_f_CV(pop, device_count);
    fes_count = fes_count + NP;  % Count initial evaluation
    
    % Reformat objectives: use energy as constraint, latency as objective
    temp = objective(:,2); % Store energy values
    objective = [objective(:,1), CV]; % New objectives: [latency, CV]
    CV = temp; % Original energy becomes constraint
    
    fitness = CalFitness(objective);
    
    pop = [pop, objective, CV];
    [pop1, pop2, pop3, pop4] = dividepop(pop, fitness);
    pop = PAR_evolve3(pop1, pop2, pop3, pop4, iter_max, device_count);
    fes_count = fes_count + iter_max * NP;  % Count evolution evaluations
    
    % Restore original objective order
    temp = pop(:,D+3); % Get stored energy
    pop(:,D+3) = pop(:,D+2); % Move CV
    pop(:,D+2) = temp; % Restore energy

% Type 4: Constrained energy optimization (single-objective)    
elseif type == 4
    [objective, CV] = get_f_CV(pop, device_count);
    fes_count = fes_count + NP;  % Count initial evaluation
    
    % Reformat objectives: use latency as constraint, energy as objective
    temp = objective(:,1); % Store latency values
    objective = [CV, objective(:,2)]; % New objectives: [CV, energy]
    CV = temp; % Original latency becomes constraint
    
    fitness = CalFitness(objective);
    
    pop = [pop, objective, CV];
    [pop1, pop2, pop3, pop4] = dividepop(pop, fitness);
    pop = PAR_evolve4(pop1, pop2, pop3, pop4, iter_max, device_count);
    fes_count = fes_count + iter_max * NP;  % Count evolution evaluations
    
    % Restore original objective order
    temp = pop(:,D+3); % Get stored latency
    pop(:,D+3) = pop(:,D+1); % Move CV
    pop(:,D+1) = temp; % Restore latency
end
end
