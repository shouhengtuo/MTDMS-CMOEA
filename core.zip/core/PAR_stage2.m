% PAR_STAGE2 - Parallel version of second stage optimization in MTDMS-CMOEA
function [pop, fes_count] = PAR_stage2(pop, iter_max, type, device_count, final_relax_rate)
% PAR_STAGE2 - Parallel version of second stage optimization in MTDMS-CMOEA
% Performs accelerated convergence with dynamic constraint handling
%
% Inputs:
%   pop      - Population matrix from stage 1 [N x D]
%   iter_max - Maximum iterations for this stage
%   type     - Membrane type identifier (1-4)
%   device_count - Number of IoT devices (passed to get_f_CV)
%   final_relax_rate - Final constraint relaxation as % of initial threshold
%                      (default: 0.05, i.e., 5%)
%
% Outputs:
%   pop       - Optimized population after stage 2
%   fes_count - Number of function evaluations performed
%
% Note: This function is designed to be called within parfor loops

%% Input Validation
if nargin < 5
    final_relax_rate = 0.05;  % Default: 5% of initial threshold
end

% Get population size and problem dimension
[N, D] = size(pop);

% Initialize FES counter
fes_count = 0;

%% Initialization Phase
% Calculate fitness for main population
fitness = CalFitness(pop(:, (D-2):(D-1)), pop(:, D));
Zmin1 = min(pop(:, (D-2):(D-1)), [], 1); % Ideal point for main population

% Initialize auxiliary population for constraint relaxation
pop_help = init_pop(N, D-3); 
[objective_help, CV_help] = get_f_CV(pop_help, device_count);
fes_count = fes_count + N;  % Count auxiliary population evaluation

pop_help = [pop_help, objective_help, CV_help]; % Append objectives and CV
fitness_help = CalFitness(objective_help, CV_help);
Zmin2 = min(pop_help(:, (D-2):(D-1)), [], 1); % Ideal point for auxiliary pop

% Initialize dynamic constraint threshold parameters
% Use logarithmic decay strategy from the paper:
% τ(t) = τ_0 * (1 - log(t+1)/log(MaxT+1))
% This ensures gradual tightening from high initial threshold to near-zero
init_CV = [pop(:, D); CV_help]; % Combined constraint violations

% Set initial threshold τ_0 as maximum CV with LARGE relaxation factor
% CRITICAL: For K=50, constraints are very strict, need aggressive exploration
VAR0 = max(init_CV) * 5.0; % Start with 5x max CV for extensive exploration
if VAR0 == 0 || isnan(VAR0)
    VAR0 = 20.0; % Larger fallback threshold for difficult problems
end

% Final threshold (NOT zero, allow MORE relaxation for near-feasible solutions)
% User-configurable parameter: Higher = more relaxed, Lower = stricter
% Recommended: 0.05 (5%) for K=50, can adjust to 0.01 (1%) or 0.10 (10%)
VAR_final = VAR0 * final_relax_rate; % User-defined relaxation rate

fprintf('Stage 2 Initialization:\n');
fprintf('  Initial CV threshold (τ_0): %.6f\n', VAR0);
fprintf('  Final CV threshold: %.6f (%.1f%% of initial)\n', VAR_final, final_relax_rate * 100);
fprintf('  Max iterations (MaxT): %d\n\n', iter_max);

%% Evolutionary Loop
iter = 0;
while iter < iter_max
    %% 1. Dynamic Constraint Threshold Update (Logarithmic Decay)
    % Paper formula: τ(t) = τ_0 * (1 - log(t+1)/log(MaxT+1))
    % This ensures:
    % - At t=0: τ(0) = τ_0 (high exploration)
    % - At t=MaxT: τ(MaxT) → VAR_final (near feasible)
    
    t = iter; % Current iteration
    MaxT = iter_max; % Maximum iterations
    
    % Logarithmic decay factor (0 at start → 1 at end)
    decay_factor = log(t + 1) / log(MaxT + 1);
    
    % Current threshold with smooth transition to final value
    VAR = VAR0 * (1 - decay_factor) + VAR_final * decay_factor;
    
    % Optional: Print progress every 10% of iterations
    if mod(iter, max(1, floor(iter_max/10))) == 0
        feasible_main = sum(pop(:, D) <= VAR);
        feasible_aux = sum(pop_help(:, D) <= VAR);
        fprintf('  Iter %d/%d: τ=%.6f, Feasible: Main=%d/%d, Aux=%d/%d\n', ...
                iter, iter_max, VAR, feasible_main, N, feasible_aux, N);
    end
    
    %% 2. Main Population Evolution
    % Generate offspring using hybrid DE strategies
    MatingPool = pop(randsample(N, N), :); % Tournament selection
    
    % Neighbor pairing for DE operators
    [Mate1, Mate2, Mate3] = Neighbor_Pairing_Strategy(MatingPool, Zmin1);
    
    % Split offspring generation into two parallel tasks
    % Task 1: DE/rand/1 for first half
    % Task 2: DE/pbest/1 for second half
    N_half = floor(N/2);
    
    % Prepare data for parallel offspring generation
    Offspring1 = zeros(N, D-3);
    
    % Generate first half using DE/rand/1
    Offspring1(1:N_half, :) = OperatorDE_rand_1(...
        Mate1(1:N_half, 1:(D-3)), Mate2(1:N_half, 1:(D-3)), Mate3(1:N_half, 1:(D-3)));
    
    % Generate second half using DE/pbest/1
    Offspring1(N_half+1:N, :) = OperatorDE_pbest_1_main(...
        pop, N-N_half, fitness, 0.1);
    
    %% 3. Auxiliary Population Evolution
    MatingPool = pop_help(randsample(N, N), :);
    [Mate1, Mate2, Mate3] = Neighbor_Pairing_Strategy(MatingPool, Zmin2);
    
    Offspring2 = zeros(N, D-3);
    
    % Generate first half using DE/rand/1
    Offspring2(1:N_half, :) = OperatorDE_rand_1(...
        Mate1(1:N_half, 1:(D-3)), Mate2(1:N_half, 1:(D-3)), Mate3(1:N_half, 1:(D-3)));
    
    % Generate second half using DE/pbest/1
    Offspring2(N_half+1:N, :) = OperatorDE_pbest_1_main(...
        pop_help, N-N_half, fitness_help, 0.1);
    
    %% 4. Parallel Offspring Evaluation
    % Evaluate both offspring populations
    [objective_Offspring1, CV_Offspring1] = get_f_CV(Offspring1, device_count);
    Offspring1 = [Offspring1, objective_Offspring1, CV_Offspring1];
    fes_count = fes_count + N;  % Count offspring1 evaluation
    
    [objective_Offspring2, CV_Offspring2] = get_f_CV(Offspring2, device_count);
    Offspring2 = [Offspring2, objective_Offspring2, CV_Offspring2];
    fes_count = fes_count + N;  % Count offspring2 evaluation
    
    %% 5. Ideal Point Update
    Zmin1 = min([Zmin1; Offspring1(:, (D-2):(D-1))], [], 1);
    Zmin2 = min([Zmin2; Offspring2(:, (D-2):(D-1))], [], 1);
    
    %% 6. Environmental Selection
    % Main population selection with strict feasibility
    [pop, fitness] = Main_task_EnvironmentalSelection(...
        [pop; Offspring1; Offspring2], N, true);
    
    % Auxiliary population selection with relaxed constraints (VAR threshold)
    [pop_help, fitness_help] = Auxiliray_task_EnvironmentalSelection(...
        [pop_help; Offspring2; Offspring1], N, VAR);
    
    %% 7. Preparation for Next Generation
    Offspring1 = Offspring1(:, 1:(D-3)); % Trim evaluation results
    Offspring2 = Offspring2(:, 1:(D-3));
    
    iter = iter + 1;
end

% Final statistics
feasible_final = sum(pop(:, D) == 0);
fprintf('\nStage 2 Completed:\n');
fprintf('  Fully feasible solutions: %d/%d\n', feasible_final, N);
fprintf('  Solutions with CV ≤ %.6f: %d/%d\n', VAR_final, sum(pop(:, D) <= VAR_final), N);
fprintf('  Total FES: %d\n\n', fes_count);
end
