function pop = PAR_evolve3(pop1, pop2, pop3, pop4, iter_max, device_count)
% PAR_EVOLVE3 - Parallel version of evolve3 for constrained latency optimization
% Eliminates global variable dependency for parallel execution
%
% Inputs:
%   pop1-pop4 - Four subpopulations from membrane division
%   iter_max  - Maximum iterations
%   device_count - Number of IoT devices (passed to get_f_CV)
%
% Output:
%   pop       - Merged optimized population

iter = 0;
N = size(pop1, 1);
D = size(pop1, 2);
pop = zeros(N, D);

while iter < iter_max
    % Calculate fitness for each population
    fitness1 = CalFitness(pop1(:,(D-2):(D-1)));
    fitness2 = CalFitness(pop2(:,(D-2):(D-1)));
    fitness3 = CalFitness(pop3(:,(D-2):(D-1)));
    fitness4 = CalFitness(pop4(:,(D-2):(D-1)));
    
    % Parent selection using tournament
    Mat1 = TournamentSelection(2, N, fitness1);
    
    % DE/best/1 for population 2
    Mat2_1 = TournamentSelection(2, N, fitness2);
    Mat2_2 = TournamentSelection(2, N, fitness2);
    
    % DE/rand/1 for population 3
    Mat3_1 = TournamentSelection(2, N, fitness3);
    Mat3_2 = TournamentSelection(2, N, fitness3);
    Mat3_3 = TournamentSelection(2, N, fitness3);
    
    % DE/current-to-rand/1 for population 4
    Mat4_1 = TournamentSelection(2, N, fitness4);
    Mat4_2 = TournamentSelection(2, N, fitness4);
    Mat4_3 = TournamentSelection(2, N, fitness4);
    
    % Generate offspring using different DE strategies (no global variable dependency)
    offspring2 = PAR_OperatorDE_best(pop1(Mat1,1:(D-3)), pop2(Mat2_1,1:(D-3)), pop2(Mat2_2,1:(D-3)));
    offspring3 = OperatorDE_rand_1(pop3(Mat3_1,1:(D-3)), pop3(Mat3_2,1:(D-3)), pop3(Mat3_3,1:(D-3)));
    offspring4 = PAR_OperatorDE_current(pop4(:,1:(D-3)), pop4(Mat4_1,1:(D-3)), pop4(Mat4_2,1:(D-3)), pop4(Mat4_3,1:(D-3)));
    
    % Evaluate offspring
    [objective_2, CV_2] = get_f_CV(offspring2, device_count);
    [objective_3, CV_3] = get_f_CV(offspring3, device_count);
    [objective_4, CV_4] = get_f_CV(offspring4, device_count);
    
    % Swap objectives for latency-focused optimization
    % Store energy values separately (they have different sizes)
    temp2 = objective_2(:,2);
    temp3 = objective_3(:,2);
    temp4 = objective_4(:,2);
    
    objective_2 = [objective_2(:,1), CV_2];
    objective_3 = [objective_3(:,1), CV_3];
    objective_4 = [objective_4(:,1), CV_4];
    
    CV_2 = temp2;
    CV_3 = temp3;
    CV_4 = temp4;
    
    % Combine parents and offspring
    Q_2 = [pop2(:,1:(D-3)); offspring2];
    Q_3 = [pop3(:,1:(D-3)); offspring3];
    Q_4 = [pop4(:,1:(D-3)); offspring4];
    Q_Obj_2 = [pop2(:,(D-2):(D-1)); objective_2];
    Q_Obj_3 = [pop3(:,(D-2):(D-1)); objective_3];
    Q_Obj_4 = [pop4(:,(D-2):(D-1)); objective_4];
    Q_CV_2 = [pop2(:,D); CV_2];
    Q_CV_3 = [pop3(:,D); CV_3];
    Q_CV_4 = [pop4(:,D); CV_4];
    
    % Constraint-dominated environmental selection
    [Next_2, fitness2] = EnvironmentalSelection(Q_Obj_2, Q_CV_2, N, false);
    [Next_3, fitness3] = EnvironmentalSelection(Q_Obj_3, Q_CV_3, N, false);
    [Next_4, fitness4] = EnvironmentalSelection(Q_Obj_4, Q_CV_4, N, false);
    
    offspring2 = Q_2(Next_2, :);
    offspring3 = Q_3(Next_3, :);
    offspring4 = Q_4(Next_4, :);
    
    pop2 = [offspring2, Q_Obj_2(Next_2,:), Q_CV_2(Next_2,:)];
    pop3 = [offspring3, Q_Obj_3(Next_3,:), Q_CV_3(Next_3,:)];
    pop4 = [offspring4, Q_Obj_4(Next_4,:), Q_CV_4(Next_4,:)];
    
    % Merge all populations
    pop = [pop1; pop2; pop3; pop4];
    fitness = [fitness1(:); fitness2(Next_2)'; fitness3(Next_3)'; fitness4(Next_4)'];
    
    % Redistribute population based on fitness
    [pop1, ~, ~, ~] = dividepop(pop, fitness);
    pop = [pop1; pop2; pop3; pop4];
    
    iter = iter + 1;
end
end
