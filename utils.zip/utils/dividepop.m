function [pop1,pop2,pop3,pop4] = dividepop(pop, fitness)
% DIVIDEPOP - Divide population into 4 subpopulations
% Handles cases where population size is not divisible by 4
%
% Inputs:
%   pop     - Population matrix [N x D]
%   fitness - Fitness values [N x 1]
%
% Outputs:
%   pop1-pop4 - Four subpopulations

    N = size(pop, 1);
    
    % Elite subpopulation size (1/4 of total)
    subPop_N = round(N / 4);
    
    % Select elite individuals based on fitness
    next = zeros(1, N);
    [~, rank] = sort(fitness);
    next(rank(1:subPop_N)) = true;
    next = logical(next);
    
    % Extract elite population (pop1)
    pop1 = pop(next, :);
    
    % Remaining individuals
    next = ~next;
    remaining_pop = pop(next, :);
    remaining_N = size(remaining_pop, 1);
    
    % Divide remaining individuals into 3 equal parts
    % Handle cases where remaining_N is not divisible by 3
    base_size = floor(remaining_N / 3);
    remainder = remaining_N - 3 * base_size;
    
    % Distribute remainder among first few populations
    sizes = [base_size, base_size, base_size];
    for i = 1:remainder
        sizes(i) = sizes(i) + 1;
    end
    
    % Split remaining population
    idx1 = sizes(1);
    idx2 = idx1 + sizes(2);
    
    pop2 = remaining_pop(1:idx1, :);
    pop3 = remaining_pop(idx1+1:idx2, :);
    pop4 = remaining_pop(idx2+1:end, :);
end