function pop = top1(pop)
        [N,D] = size(pop);
        %初始化选出来的精英个体
        next = zeros(1,N);
        fitness = CalFitness(pop(:,(D-2):(D-1)),pop(:,D));
        [~,rank] = sort(fitness);
        next(rank(1)) = true;
        next = logical(next);
        %精英个体
        pop = pop(next,:);
end