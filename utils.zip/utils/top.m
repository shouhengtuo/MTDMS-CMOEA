function pop = top(pop)
        [N,D] = size(pop);
        %当前子种群大小
        subPop_N = N / 2;
        %初始化选出来的精英个体
        next = zeros(1,size(pop,1));
        fitness = CalFitness(pop(:,(D-2):(D-1)),pop(:,D));
        [~,rank] = sort(fitness);
        next(rank(1:subPop_N)) = true;
        next = logical(next);
        %精英个体
        pop = pop(next,:);
end