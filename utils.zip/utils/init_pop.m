function pop  = init_pop(N,D)
%种群初始化
    count = D-120;
    low = [zeros(1,count+120)];
    up = [ones(1,count)*6,ones(1,120)];
    pop = zeros(N,D);
    for i=1:D
        pop(:, i) = randi([low(i),up(i)],[N, 1]);
    end
end
            
            