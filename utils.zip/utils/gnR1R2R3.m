function [r1,r2,r3] = gnR1R2R3(NP1, r0)
%随机生成三个不重复的随机数


    NP0 = length(r0);

    r1  = floor(rand(1, NP0) * NP1) + 1;
    for i = 1 : 999
        pos = (r1 == r0);
        if sum(pos) == 0
            break;
        else            %重新生成r1
            r1(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
        end
    end

    r2  = floor(rand(1, NP0) * NP1) + 1;
    for i = 1 : 999
        pos = ((r2 == r1) | (r2 == r0));
        if sum(pos) == 0
            break;
        else            % regenerate r2 if it is equal to r0 or r1
            r2(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
        end
    end

    r3  = floor(rand(1, NP0) * NP1) + 1;
    for i = 1 : 999
        pos = ((r3 == r1) | (r3 == r0) | (r3 == r2));
        if sum(pos) == 0
            break;
        else            % regenerate r2 if it is equal to r0 or r1
            r3(pos) = floor(rand(1, sum(pos)) * NP1) + 1;
        end
    end
end