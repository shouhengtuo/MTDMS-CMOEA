function [Next,Fitness] = EnvironmentalSelection(objective,CV,N,isOrigin)
%环境选择
    % 用以判断以哪种方式计算Fitness
    if isOrigin
        Fitness = CalFitness(objective,CV);
    else
        Fitness = CalFitness(objective);
    end
    Next = Fitness < 1;
    % 如果fitness < 1的解不够个体数，则进行排序取前N个
    if sum(Next) < N
        [~,Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    % 如果大于N则需要截断
    elseif sum(Next) > N
        Del  = Truncation(objective(Next,:),sum(Next)-N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end
%     Population = Population(Next);
%     Fitness    = Fitness(Next);
end
function Del = Truncation(PopObj,K)
    % 计算个体之间的余弦相似度
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        % 找到还存在的解
        Remain = find(~Del);
        % 将这些解按照行进行排序，也就是第一列为距离对应解最近的解
        Temp = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        % 找出距离其他解最近解的解序号将其删除
        Del(Remain(Rank(1))) = true;
    end
end
