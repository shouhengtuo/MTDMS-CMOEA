function [Population,Fitness] = Main_task_EnvironmentalSelection(Population,N,isOrigin)
%第二阶段主任务环境选择
    [~,D] = size(Population);
    if isOrigin 
        Fitness = CalFitness(Population(:,(D-2):(D-1)),Population(:,D));
    else
        Fitness = CalFitness(Population(:,(D-2):(D-1)));
    end


    Next = Fitness < 1;
    if sum(Next) < N
        [~,Rank] = sort(Fitness);
        Next(Rank(1:N)) = true;
    elseif sum(Next) > N
        Del  = Truncation(Population(Next,(D-2):(D-1)),sum(Next)-N);
        Temp = find(Next);
        Next(Temp(Del)) = false;
    end

    Population = Population(Next,:);
    Fitness    = Fitness(Next);

    [Fitness,rank] = sort(Fitness);
    Population = Population(rank,:);
end

function Del = Truncation(PopObj,K)
    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end