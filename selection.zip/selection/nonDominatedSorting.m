function [fronts, ranks] = nonDominatedSorting(population)
% nonDominatedSort
    % With two objectives, the input population is an N * 2 matrix, where N is the number of solutions in the population and 2 is the number of objectives 
    % Getting the number of solutions
    numSolutions = size(population, 1);
    % Initialise the dominance relation matrix N * N
    dominanceMatrix = zeros(numSolutions); 

    % Calculation of the dominance matrix
    for i = 1:numSolutions
        for j = i+1:numSolutions
            if dominates(population(i, :), population(j, :))
                dominanceMatrix(i, j) = 1; % i dominate j
            elseif dominates(population(j, :), population(i, :))
                dominanceMatrix(j, i) = 1; % j dominate i
            end
        end
    end
    % The N-dimensional vector indicates how many other individuals are dominated by the corresponding indexed individual
    dominationCount = sum(dominanceMatrix, 1);
    % Storing arrays of cells with non-dominated fronts
    fronts = cell(1, numSolutions); 
    % Stores the level of each solution
    ranks = zeros(1, numSolutions); 
    currentFront = 1;
    % Finding individuals who are not dominated at this time
    currentFrontIndices = find(dominationCount == 0);
    % If non-empty
    while ~isempty(currentFrontIndices)
        % Stores the index of the corresponding layer
        fronts{currentFront} = currentFrontIndices;
        ranks(currentFrontIndices) = currentFront;

        nextFrontIndices = [];
        for i = currentFrontIndices
            % Finds the serial number of an individual that is dominated by an individual that has been stored to front
            dominatedIndices = find(dominanceMatrix(i, :) == 1);
            dominationCount(dominatedIndices) = dominationCount(dominatedIndices) - 1;
            nextFrontIndices = [nextFrontIndices dominatedIndices(dominationCount(dominatedIndices) == 0)];
        end

        currentFront = currentFront + 1;
        currentFrontIndices = nextFrontIndices;
    end
end

function result = dominates(solution1, solution2)
    % Check if solution1 dominates solution2
    if all(solution1 <= solution2) && any(solution1 < solution2)
        result = true;
    else
        result = false;
    end
end



