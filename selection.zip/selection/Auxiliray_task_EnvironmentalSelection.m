function [return_pop,return_Fitness] = Auxiliray_task_EnvironmentalSelection(Population,N,VAR)
%辅助种群选择分为三种情况
% Inputs:
%   Population - Combined population [parent + offspring]
%   N - Target population size
%   VAR - Dynamic constraint violation threshold (logarithmic decay)
%
% Selection Strategy:
%   1. Prioritize individuals with CV <= VAR (relaxed feasibility)
%   2. Use non-dominated sorting and crowding distance for selection
%   3. Ensure population diversity through truncation

    [~,D] = size(Population);
    input_cons = Population(:,D); % Constraint violation values
    
    % Separate population based on dynamic threshold
    findex = input_cons <= VAR;  % Relaxed feasible (CV <= threshold)
    ifindex = input_cons > VAR;  % Infeasible (CV > threshold)

    fPopulation = Population(findex,:);   % Relaxed feasible population
    ifPopulation = Population(ifindex,:); % Infeasible population
    %% Case 1: No relaxed feasible solutions (all CV > VAR)
    % Select best infeasible solutions based on objectives and CV
    if isempty(fPopulation)
        ifFitness = CalFitness(ifPopulation(:,(D-2):(D-1)),ifPopulation(:,D));
        Next2 = ifFitness < 1;
        
        % If not enough non-dominated solutions, select by fitness ranking
        if sum(Next2) <= N
            [~,Rank] = sort(ifFitness);
            Next2(Rank(1:N)) = true;
        % If too many non-dominated solutions, use crowding distance truncation
        elseif sum(Next2) > N
            Del = Truncation(ifPopulation(Next2,(D-2):(D-1)), sum(Next2)-N);
            Temp = find(Next2);
            Next2(Temp(Del)) = false;
        end

        ifPopulation = ifPopulation(Next2,:);
        ifFitness = ifFitness(Next2);

        [ifFitness,rank] = sort(ifFitness);
        ifPopulation = ifPopulation(rank,:);

        fPopulation = [];
        fFitness = [];
    %% Case 2: Insufficient relaxed feasible solutions (CV <= VAR < N)
    % Fill remaining slots with best infeasible solutions
    elseif size(fPopulation,1) <= N
        cons = fPopulation(:,D);
        % Calculate fitness considering CV as soft constraint
        fFitness = CalFitness([fPopulation(:,(D-2):(D-1)),cons]);
        Next = fFitness < 1;

        [~,Rank] = sort(fFitness);
        Next(Rank(1:size(fPopulation,1))) = true;

        fPopulation = fPopulation(Next,:);
        fFitness = fFitness(Next);

        [fFitness,rank] = sort(fFitness);
        fPopulation = fPopulation(rank,:);
        
        % Fill remaining slots from infeasible population
        needed = N - size(fPopulation,1);
        ifFitness = CalFitness(ifPopulation(:,(D-2):(D-1)),ifPopulation(:,D));
        Next2 = ifFitness < 1;
        
        if sum(Next2) <= needed
            [~,Rank] = sort(ifFitness);
            Next2(Rank(1:needed)) = true;
        elseif sum(Next2) > needed
            Del = Truncation(ifPopulation(Next2,(D-2):(D-1)), sum(Next2)-needed);
            Temp = find(Next2);
            Next2(Temp(Del)) = false;
        end

        ifPopulation = ifPopulation(Next2,:);
        ifFitness = ifFitness(Next2) + max(fFitness); % Penalize infeasible
        
        % Sort the population
        [ifFitness,rank] = sort(ifFitness);
        ifPopulation = ifPopulation(rank,:);
    %% Case 3: Sufficient relaxed feasible solutions (CV <= VAR >= N)
    % Select best N solutions from relaxed feasible population
    elseif size(fPopulation,1) > N
        cons = fPopulation(:,D);

        fFitness = CalFitness([fPopulation(:,(D-2):(D-1)),cons]);
        Next = fFitness < 1;
        
        % If not enough non-dominated solutions, select by fitness ranking
        if sum(Next) <= N
            [~,Rank] = sort(fFitness);
            Next(Rank(1:N)) = true;
        % If too many non-dominated solutions, use crowding distance truncation
        elseif sum(Next) > N
            Del = Truncation(fPopulation(Next,(D-2):(D-1)), sum(Next)-N);
            Temp = find(Next);
            Next(Temp(Del)) = false;
        end

        fPopulation = fPopulation(Next,:);
        fFitness = fFitness(Next);
        
        % Sort the population
        [fFitness,rank] = sort(fFitness);
        fPopulation = fPopulation(rank,:);

        ifPopulation = [];
        ifFitness = [];
    end

    return_pop = [fPopulation;ifPopulation];
    return_Fitness = [fFitness,ifFitness];
end

function Del = Truncation(PopObj,K)
% Select part of the solutions by truncation


    Distance = pdist2(PopObj,PopObj);
    Distance(logical(eye(length(Distance)))) = inf;
    Del = false(1,size(PopObj,1));
    while sum(Del) < K
        Remain   = find(~Del);
        if isempty(Remain)
            keyboard
        end
        Temp     = sort(Distance(Remain,Remain),2);
        [~,Rank] = sortrows(Temp);
        Del(Remain(Rank(1))) = true;
    end
end