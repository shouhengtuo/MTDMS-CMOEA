function Offspring = PAR_OperatorDE_best(Parent_best, Parent1, Parent2)
% PAR_OPERATORDE_BEST - DE/best/1 mutation without global variable dependency
% Parallel-safe version for use in parfor loops
%
% Inputs:
%   Parent_best - Best individuals [N x D]
%   Parent1     - First random parent [N x D]
%   Parent2     - Second random parent [N x D]
%
% Output:
%   Offspring   - Generated offspring [N x D]
%
% Strategy: offspring = best + F * (Parent1 - Parent2)

[proM, disM] = deal(1, 20);
[N, D] = size(Parent_best);

% Fixed DE parameters (no iteration dependency)
F = 0.7;   % Mutation factor (fixed value for parallel execution)
CR = 0.8;  % Crossover rate (fixed value for parallel execution)

% Mutation: DE/best/1
Site = rand(N, D) < CR;
Offspring = Parent_best;
Offspring(Site) = Offspring(Site) + F * (Parent1(Site) - Parent2(Site));

% Boundary handling
low = zeros(1, D);
up = [ones(1, D-120)*6, ones(1, 120)];
Lower = repmat(low, N, 1);
Upper = repmat(up, N, 1);

% Polynomial mutation
Site = rand(N, D) < proM/D;
mu = rand(N, D);
temp = Site & mu <= 0.5;
Offspring = min(max(Offspring, Lower), Upper);
Offspring(temp) = Offspring(temp) + (Upper(temp)-Lower(temp)) .* ...
    ((2.*mu(temp) + (1-2.*mu(temp)) .* ...
    (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)) - 1);
temp = Site & mu > 0.5;
Offspring(temp) = Offspring(temp) + (Upper(temp)-Lower(temp)) .* ...
    (1 - (2.*(1-mu(temp)) + 2.*(mu(temp)-0.5) .* ...
    (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));

Offspring = round(Offspring);
end
