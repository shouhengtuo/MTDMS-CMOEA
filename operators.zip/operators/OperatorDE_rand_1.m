function Offspring = OperatorDE_rand_1(Parent1,Parent2,Parent3)
    [proM,disM] = deal(1,20);
    [N,D]   = size(Parent1);
    % Parents are already decision variables only, no need to extract again
    Fm = [0.6,0.8,1.0];
    CRm=[0.1,0.2,1.0];
    index = randi([1,length(Fm)],N,1);
    F = Fm(index);
    F = F';
    F = F(:, ones(1,D));
    index = randi([1,length(CRm)],N,1);
    CR = CRm(index);
    CR = CR';


    Site = rand(N,D) < CR;
    Offspring       = Parent1;
    Offspring(Site) = Offspring(Site) + F(Site).*(Parent2(Site)-Parent3(Site));


    low = zeros(1,D); % 下界
    up = [ones(1,D-120)*6,ones(1,120)]; % 上界
    Lower = repmat(low, N, 1); % 扩展下界矩阵
    Upper = repmat(up, N, 1); % 扩展上界矩阵
    Site  = rand(N,D) < proM/D;
    mu    = rand(N,D);
    temp  = Site & mu<=0.5;
    Offspring       = min(max(Offspring,Lower),Upper);
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
        (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
    temp = Site & mu>0.5;
    Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
        (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
    Offspring = round(Offspring);
end