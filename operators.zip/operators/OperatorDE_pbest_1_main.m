function [ Offspring ] = OperatorDE_pbest_1_main(Population, popsize, Fitness, p)
    [N,~] = size(Population);
    permutation = randperm(N);
    r0 = permutation;
    [r1,r2,r3] = gnR1R2R3(N, r0);

    array = permutation(1:popsize);
    pop1 = Population(array);

    [~, indBest] = sort(Fitness, 'ascend');
    pNP = max(round(p * N), 2);          
    randindex = ceil(rand(1, popsize) * pNP);	
    randindex = max(1, randindex);             
    pbest = Population(indBest(randindex),:);     

    Offspring = OperatorDE_pbest_1(Population(array,:),pbest,Population(r1(1:popsize),:),Population(r2(1:popsize),:));
end