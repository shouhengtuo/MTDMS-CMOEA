function Offspring = OperatorSafeDE(varargin)
    [CR,F,F1,proM,disM] = deal(1,0.5,0.5,1,20);
    if nargin == 4
        pop1 =[varargin{1}];
        pop2 =[varargin{2}];
        pop3 =[varargin{3}];
        pop4 =[varargin{4}];
        [N, D] = size(pop1); % 获取种群大小和维度
        Site = rand(N,D) < CR;
        Offspring = pop1;
        % DE/current-to-rand/1 变异策略
        Offspring(Site) = Offspring(Site) + F * (pop2(Site) - Offspring(Site)) + F1 * (pop3(Site) - pop4(Site));
        % 边界处理
        low = ones(1,D); % 下界
        up = ones(1,D)*5; % 上界
        Lower = repmat(low, N, 1); % 扩展下界矩阵
        Upper = repmat(up, N, 1); % 扩展上界矩阵
        Site  = rand(N,D) < proM/D;
        mu    = rand(N,D);
        temp  = Site & mu<=0.5;
        Offspring = min(max(Offspring, Lower), Upper); % 确保个体在边界内
         Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
            (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
        temp = Site & mu>0.5;
        Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
            (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
        % 四舍五入
        Offspring = round(Offspring);
    else
        pop1 =[varargin{1}];
        pop2 =[varargin{2}];
        pop3 =[varargin{3}];
        [N, D] = size(pop1); % 获取种群大小和维度
        %交叉
        Site = rand(N,D) < CR;
        Offspring       = pop1;
        Offspring(Site) = Offspring(Site) + F*(pop2(Site)-pop3(Site));
        %边界控制，变异
        low = zeros(1,D); % 下界
        up = [ones(1,D-120)*6,ones(1,120)]; % 上界
        Lower = repmat(low,N,1);
        Upper = repmat(up,N,1);
        Site  = rand(N,D) < proM/D;
        mu    = rand(N,D);
        temp  = Site & mu<=0.5;
        Offspring       = min(max(Offspring,Lower),Upper);
        Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*((2.*mu(temp)+(1-2.*mu(temp)).*...
            (1-(Offspring(temp)-Lower(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1))-1);
        temp = Site & mu>0.5;
        Offspring(temp) = Offspring(temp)+(Upper(temp)-Lower(temp)).*(1-(2.*(1-mu(temp))+2.*(mu(temp)-0.5).*...
            (1-(Upper(temp)-Offspring(temp))./(Upper(temp)-Lower(temp))).^(disM+1)).^(1/(disM+1)));
        Offspring = round(Offspring);
     end



end
